// 
// Decompiled by Procyon v0.5.36
// 

package qolskyblockmod.pizzaclient.features.macros.builder;

public enum MacroState
{
    ACTIVE, 
    NEW_THREAD, 
    FAILSAFE;
}
